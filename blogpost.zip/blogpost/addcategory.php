<?php
session_start();
include("db.php");
include "allheader.php";
if(!isset($_SESSION['user_role'])){
echo "You are not admin";
header("Location:login.php");
}
else{

   if($_SESSION['user_role']=="admin"){
    if(isset($_POST['submit'])){
        $name=$_POST['name'];
$sql = "INSERT INTO category(name)VALUES('$name')";
$result = mysqli_query($conn,$sql);
if(!$result){
    echo "Error!:{$conn->error}";
}
else{
    echo "Category added successfully";
   } 
}
}
   else{
    header( "location:dashboard.php");
   }
}
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta name=""viewport" content="width=device-width,initial_scale=1">
        <title>
        </title>
</head>
    <body>
        <form action="addcategory.php"method="POST">
           <input type="text" name="name">
           <input type="submit"name="submit"value="add category">
            <a href='dashboard.php'>Dashboard</a>
        </form>

    </body>
</html>
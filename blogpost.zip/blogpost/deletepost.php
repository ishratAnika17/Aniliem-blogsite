<?php
session_start();
include "db.php";
include "allheader.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SESSION['user_role'] == "subscriber") {
    header("Location: dashboard.php");
    exit;
}

if (isset($_GET['post_id'])) {
    $post_id = $_GET['post_id'];

    /* ---------- CHECK IF AUTHOR OF THIS POST ---------- */
    $check_sql = "SELECT id FROM posts WHERE id='$post_id' AND author_id='$user_id'";
    $check_result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_result) == 0) {
        die("You are not allowed to delete this post");
    }

    /* ---------- DELETE CHILD COMMENTS FIRST ---------- */
    mysqli_query($conn, "DELETE FROM comments WHERE post_id='$post_id'");

    /* ---------- DELETE POST ---------- */
    $sql = "DELETE FROM posts WHERE id='$post_id'";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        echo "Error!: {$conn->error}";
    } else {
        echo "Deleted successfully!";
    }
} else {
    die("Post ID missing");
}
?>

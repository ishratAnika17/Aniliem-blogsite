<?php
$server="localhost";
$user="root";
$password="";
$dbname="blogpostdb";
$conn=new mysqli($server,$user,$password,$dbname);
if (!$conn){
    echo "error!:{$conn->connect_error}";
}

?>
<?php
session_start();
include "db.php";
include "allheader.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get the post ID
if (isset($_GET['post_id'])) {
    $post_id = $_GET['post_id'];
} else {
    die("Post ID missing");
}

// Only allow subscribers to comment
if ($_SESSION['user_role'] != "subscriber") {
    die("Only subscribers are allowed to comment.");
}

// Handle comment submission
if (isset($_POST['submit'])) {
    $user_name = $_SESSION['user_name'];
    $user_email = $_SESSION['user_email'];
    $user_comment = $_POST['comment'];

    $sql = "INSERT INTO comments(post_id, user_name, email, comment) 
            VALUES ('$post_id', '$user_name', '$user_email', '$user_comment')";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        echo "Error!: {$conn->error}";
    } else {
        echo "Comment added successfully!";
    }
}
?>

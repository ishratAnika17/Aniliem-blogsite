<?php
include"db.php";
include "allheader.php";
session_start();
if( isset($_POST['submit'])){
 $name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$role=$_POST['role'];

$sql="INSERT INTO user (name,email,password,role) VALUES('$name','$email','$password','$role')";
$result=mysqli_query($conn,$sql);
if($result){
    echo "Error:{$conn->error}";
}else{
echo "The registration is done successfully";
}
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>document</title>
    </head>
    <body>
        <form action="register.php" method="post">
            Name:<input type="text"name="name" required><br>
            Email:<input type="email"name="email" required><br>
            Password:<input type="password"name="password" required><br>
            Role:
            <select name="role">
                <option value="subscriber">Subscriber</option>
                <option value="author">Author</option>
            </select><br>
            <input type="submit"name="submit"value="Register">
        </form>
    </body>
</html>
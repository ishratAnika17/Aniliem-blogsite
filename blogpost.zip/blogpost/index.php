<?php
include "displaypost.php";




?>
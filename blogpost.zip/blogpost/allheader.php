<!DOCTYPE html>
<html>
    <head>
        
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>
        </title>
    <link rel="stylesheet" type="text/css" href="style.css">

    </head>
    <body>
<header class="mainheader">
   <p><b>Aniliem Blog Site<b></p>
    
    <ul>
        <li><a href="register.php">Sign up</a></li>
         <li><a href="dashboard.php">Dashboard</a></li>
    </ul>
</header>
<div class="blog-intro" style="background-color:#f3e5f5; padding:30px; text-align:center; border-radius:8px; margin:20px;">
    <h1>Welcome to Aniliem Blog</h1>
    <p style="font-size:16px; color:#333; max-width:1500px; margin:0 auto;">
        Welcome to Aniliem Blog! This is your space for stories, ideas, and insights across a variety of topics—from technology and travel to lifestyle and creative inspiration. Explore the latest posts below, join the conversation by leaving your comments, and be part of our growing community of readers.
    </p>
</div>

    </body>
</html>
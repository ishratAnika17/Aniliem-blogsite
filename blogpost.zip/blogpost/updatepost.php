<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "allheader.php";
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if (isset($_GET['post_id'])) {
    $post_id = $_GET['post_id'];
} else {
    die("Post ID missing");
}

/* ---------- FETCH CATEGORIES ---------- */
$sql = "SELECT * FROM category";
$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Category Error: " . mysqli_error($conn));
}

/* ---------- UPDATE POST ---------- */
if ($_SESSION['user_role'] == "Author") {

    if (isset($_POST['submit'])) {

        $title = $_POST['title'];
        $content = $_POST['content'];
        $category_name = $_POST['category_name'];

        /* ---------- IMAGE HANDLING ---------- */
        if (!empty($_FILES['image']['name'])) {
            $name = $_FILES['image']['name'];
            $temp_location = $_FILES['image']['tmp_name'];
            $our_location = "image/";
            move_uploaded_file($temp_location, $our_location . $name);
        } else {
            $name = ""; // no new image
        }

        /* ---------- GET CATEGORY ID ---------- */
        $sql1 = "SELECT id FROM category WHERE name='$category_name'";
        $result1 = mysqli_query($conn, $sql1);
        if ($result1 && mysqli_num_rows($result1) > 0) {
            $row = mysqli_fetch_assoc($result1);
            $idforcategory = $row['id'];
        } else {
            die("Category not found");
        }

        /* ---------- AUTHOR OWNERSHIP CHECK ---------- */
        $check_sql = "SELECT id FROM posts WHERE id='$post_id' AND author_id='$user_id'";
        $check_result = mysqli_query($conn, $check_sql);

        if (mysqli_num_rows($check_result) == 0) {
            die("You are not allowed to update this post");
        }

        /* ---------- UPDATE QUERY ---------- */
        if ($name != "") {
            $sql2 = "UPDATE posts 
                     SET title='$title',
                         content='$content',
                         category_id='$idforcategory',
                         image='$name'
                     WHERE id='$post_id'";
        } else {
            $sql2 = "UPDATE posts 
                     SET title='$title',
                         content='$content',
                         category_id='$idforcategory'
                     WHERE id='$post_id'";
        }

        $result2 = mysqli_query($conn, $sql2);

        if ($result2) {
            echo "<p style='color:green;'>Post updated successfully!</p>";
        } else {
            echo "Update Error: " . mysqli_error($conn);
        }
    }
} else {
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Update Post</title>
</head>
<body>

<form action="updatepost.php?post_id=<?php echo $post_id; ?>" 
      method="post" 
      enctype="multipart/form-data">

    <input type="text" name="title" placeholder="Give the post title here!" required><br><br>

    <textarea name="content" placeholder="Write the post here!" required></textarea><br><br>

    <select name="category_name" required>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <option value="<?php echo $row['name']; ?>">
                <?php echo $row['name']; ?>
            </option>
        <?php } ?>
    </select><br><br>

    <input type="file" name="image"><br><br>

    <input type="submit" name="submit" value="Update Post">

</form>

</body>
</html>


<?php
session_start();
if(isset($_SESSION['user_name'])){
$user_name=$_SESSION['user_name'];
}
include "allheader.php";
include"db.php";
$sql = "select*from posts";
$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_assoc($result)){
    echo "<b>{$row['title']}<b><br>";
    echo "{$row['content']}<br>";
    echo "<img src='image/{$row['image']}'><br><hr>";
    echo "<a href='updatepost.php?post_id={$row['id']}'>update</a> 
    <a href='deletepost.php?post_id={$row['id']}'>delete</a><br>"; 
 $post_id=$row['id'];
    $sql2="select*from comments where post_id='$post_id'";
$result2=mysqli_query($conn, $sql2);
while($row2=mysqli_fetch_assoc($result2)){
    echo "name:{$row2['user_name']} comment:{$row2['comment']}<br>";

}
    echo " <form action='insertcomment.php?post_id={$row['id']}'method='post'>
        <textarea name='comment' placeholder='Write your comment here!!'></textarea>
<input type='submit'name='submit'value='add comment'>
    </form>";
    
    
}


?>
